
def cash (): 
    x = float(input("your owend :"))
    cents = round (x*100)
    coins = 0
    if x > 0 :
       
        if (cents >= 25):
            cents -= 25
            coins +1
        if (cents >= 10):
            cents -= 10
            coins +1
        if (cents >= 5):
            cents -= 5
            coins +1
        if (cents >= 1):
            cents -= 1
            coins +1
    return (coins)
    print(coins)
            
        
